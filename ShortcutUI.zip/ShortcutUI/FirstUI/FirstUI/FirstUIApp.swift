//
//  FirstUIApp.swift
//  FirstUI
//
//  Created by Noura Alowayid on 25/10/1444 AH.
//

import SwiftUI

@main
struct FirstUIApp: App {
    var body: some Scene {
        WindowGroup {
            ShowWhatsNew()
        }
    }
}
